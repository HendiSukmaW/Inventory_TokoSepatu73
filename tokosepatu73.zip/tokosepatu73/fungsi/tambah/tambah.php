<?php 
session_start();
if(!empty($_SESSION['admin'])){
	require '../../config.php';
	if(!empty($_GET['kategori'])){
		$nama= $_POST['kategori'];
		$tgl= date("j F Y, G:i");
		$data[] = $nama;
		$data[] = $tgl;
		$sql = 'INSERT INTO kategori (nama_kategori,tgl_input) VALUES(?,?)';
		$row = $config -> prepare($sql);
		$row -> execute($data);
		echo '<script>window.location="../../index.php?page=kategori&&success=tambah-data"</script>';
	}
	if(!empty($_GET['barang'])){
		$id = $_POST['id'];
		$kategori = $_POST['kategori'];
		$nama = $_POST['nama'];
		$merk = $_POST['merk'];
		$warna = $_POST['warna'];
		$ukuran = $_POST['ukuran'];
		$beli = $_POST['beli'];
		$jual = $_POST['jual'];
		$satuan = $_POST['satuan'];
		$stok = $_POST['stok'];
		$tgl = $_POST['tgl'];

		$target_dir = "C:/xampp/htdocs/tokosepatu73/assets/file/";
		$file_name = basename($_FILES["image"]["name"]);
		$target_file = $target_dir . $file_name;
		$uploadOk = 1;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		$check = getimagesize($_FILES["image"]["tmp_name"]);
		if($check) {
			move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
			echo "sukses";
		}else echo "gagal";
		
		$data[] = $id;
		$data[] = $kategori;
		$data[] = $nama;
		$data[] = $merk;
		$data[] = $warna;
		$data[] = $ukuran;
		$data[] = $beli;
		$data[] = $jual;
		$data[] = $satuan;
		$data[] = $stok;
		$data[] = $tgl;

		$data[] = $file_name;
		// return $data;
		$sql = 'INSERT INTO barang (id_barang,id_kategori,nama_barang,merk,warna,ukuran,harga_beli,harga_jual,satuan_barang,stok,tgl_input,gambar) VALUES (?,?,?,?,?,?,?,?,?,?,?,?) ';
		// $sql = 'INSERT INTO barang (id_barang,id_kategori,nama_barang,merk,warna,ukuran,harga_beli,harga_jual,satuan_barang,stok,tgl_input) VALUES (?,?,?,?,?,?,?,?,?,?,?)';
		$row = $config->prepare($sql);
		$row->execute($data);
		// print_r($data);exit;
		echo '<script>window.location="../../index.php?page=barang&success= -data"</script>';
	}
	if(!empty($_GET['jual'])){
		$id = $_GET['id'];
		
		// get tabel barang id_barang 
		$sql = 'SELECT * FROM barang WHERE id_barang = ?';
		$row = $config->prepare($sql);
		$row->execute(array($id));
		$hsl = $row->fetch();

		if($hsl['stok'] > 0)
		{
			$kasir =  $_GET['id_kasir'];
			$jumlah = 1;
			$total = $hsl['harga_jual'];
			$tgl = date("j F Y, G:i");
			
			$data1[] = $id;
			$data1[] = $kasir;
			$data1[] = $jumlah;
			$data1[] = $total;
			$data1[] = $tgl;
			
			$sql1 = 'INSERT INTO penjualan (id_barang,id_member,jumlah,total,tanggal_input) VALUES (?,?,?,?,?)';
			$row1 = $config -> prepare($sql1);
			$row1 -> execute($data1);

			echo '<script>window.location="../../index.php?page=jual&success=tambah-data"</script>';

		}else{
			echo '<script>alert("Stok Barang Anda Telah Habis !");
					window.location="../../index.php?page=jual#keranjang"</script>';
		}
	}
	if(!empty($_GET['barang-masuk'])){
		$barang = $_POST['barang'];
		$stok = $_POST['stok'];
		$tgl = $_POST['tgl'];
		
		$data[] = $barang;
		$data[] = $stok;
		$data[] = $tgl;
		$sql = 'INSERT INTO barangmasuk (idbarang,stok,tanggal) 
			    VALUES (?,?,?) ';
		$row = $config -> prepare($sql);
		$row -> execute($data);

		$data1[] = $barang;
		$sql1 ="SELECT stok FROM barang where id = ?";
		$row1 = $config -> prepare($sql1);
		$row1 -> execute($data1);
		$hasil = $row1 -> fetch();

		$data2[] = $hasil['stok']+$stok;
		$data2[] = $barang;
		$sql2 = 'UPDATE barang SET stok=? WHERE id = ?';
		$row2 = $config -> prepare($sql2);
		$row2 -> execute($data2);
		echo '<script>window.location="../../index.php?page=barang-masuk&success=tambah-data"</script>';
	}
	if(!empty($_GET['barang-keluar'])){
		$barang = $_POST['barang'];
		$stok = $_POST['stok'];
		$tgl = $_POST['tgl'];
		
		$data[] = $barang;
		$data[] = $stok;
		$data[] = $tgl;
		$sql = 'INSERT INTO barangkeluar (idbarang,stok,tanggal) 
			    VALUES (?,?,?) ';
		$row = $config -> prepare($sql);
		$row -> execute($data);

		$data1[] = $barang;
		$sql1 ="SELECT stok FROM barang where id = ?";
		$row1 = $config -> prepare($sql1);
		$row1 -> execute($data1);
		$hasil = $row1 -> fetch();

		$data2[] = $hasil['stok']-$stok;
		$data2[] = $barang;
		$sql2 = 'UPDATE barang SET stok=? WHERE id = ?';
		$row2 = $config -> prepare($sql2);
		$row2 -> execute($data2);
		echo '<script>window.location="../../index.php?page=barang-keluar&success=tambah-data"</script>';
	}
}