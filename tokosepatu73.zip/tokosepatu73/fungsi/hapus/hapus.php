<?php 
session_start();
if(!empty($_SESSION['admin'])){
	require '../../config.php';
	if(!empty($_GET['kategori'])){
		$id= $_GET['id'];
		$data[] = $id;
		$sql = 'DELETE FROM kategori WHERE id_kategori=?';
		$row = $config -> prepare($sql);
		$row -> execute($data);
		echo '<script>window.location="../../index.php?page=kategori&&remove=hapus-data"</script>';
	}
	if(!empty($_GET['barang'])){
		$id= $_GET['id'];
		$data[] = $id;
		$sql = 'DELETE FROM barang WHERE id_barang=?';
		$row = $config -> prepare($sql);
		$row -> execute($data);
		echo '<script>window.location="../../index.php?page=barang&&remove=hapus-data"</script>';
	}
	if(!empty($_GET['jual'])){
		
		$dataI[] = $_GET['brg'];
		$sqlI = 'select*from barang where id_barang=?';
		$rowI = $config -> prepare($sqlI);
		$rowI -> execute($dataI);
		$hasil = $rowI -> fetch();
		
		/*$jml = $_GET['jml'] + $hasil['stok'];
		
		$dataU[] = $jml;
		$dataU[] = $_GET['brg'];
		$sqlU = 'UPDATE barang SET stok =? where id_barang=?';
		$rowU = $config -> prepare($sqlU);
		$rowU -> execute($dataU);*/
		
		$id = $_GET['id'];
		$data[] = $id;
		$sql = 'DELETE FROM penjualan WHERE id_penjualan=?';
		$row = $config -> prepare($sql);
		$row -> execute($data);
		echo '<script>window.location="../../index.php?page=jual"</script>';
	}
	if(!empty($_GET['penjualan'])){
		
		$sql = 'DELETE FROM penjualan';
		$row = $config -> prepare($sql);
		$row -> execute();
		echo '<script>window.location="../../index.php?page=jual"</script>';
	}
	if(!empty($_GET['laporan'])){
		
		$sql = 'DELETE FROM nota';
		$row = $config -> prepare($sql);
		$row -> execute();
		echo '<script>window.location="../../index.php?page=laporan&remove=hapus"</script>';
	}
	if(!empty($_GET['barang-masuk'])){
		$id= $_GET['id'];
		$data[] = $id;

		$sql0 ="SELECT idbarang, stok FROM barangmasuk where id = ?";
		$row0 = $config -> prepare($sql0);
		$row0 -> execute($data);
		$hasil_barang_masuk = $row0 -> fetch();

		$data1[] = $hasil_barang_masuk['idbarang'];
		$sql1 ="SELECT stok FROM barang where id = ?";
		$row1 = $config -> prepare($sql1);
		$row1 -> execute($data1);
		$hasil = $row1 -> fetch();

		$data2[] = $hasil['stok']-$hasil_barang_masuk['stok'];
		$data2[] = $hasil_barang_masuk['idbarang'];
		$sql2 = 'UPDATE barang SET stok=? WHERE id = ?';
		$row2 = $config -> prepare($sql2);
		$row2 -> execute($data2);

		$sql3 = 'DELETE FROM barangmasuk WHERE id=?';
		$row3 = $config -> prepare($sql3);
		$row3 -> execute($data);
		echo '<script>window.location="../../index.php?page=barang-masuk&&remove=hapus-data"</script>';
	}
	if(!empty($_GET['barang-keluar'])){
		$id= $_GET['id'];
		$data[] = $id;

		$sql0 ="SELECT idbarang, stok FROM barangkeluar where id = ?";
		$row0 = $config -> prepare($sql0);
		$row0 -> execute($data);
		$hasil_barang_keluar = $row0 -> fetch();

		$data1[] = $hasil_barang_keluar['idbarang'];
		$sql1 ="SELECT stok FROM barang where id = ?";
		$row1 = $config -> prepare($sql1);
		$row1 -> execute($data1);
		$hasil = $row1 -> fetch();

		$data2[] = $hasil['stok']+$hasil_barang_keluar['stok'];
		$data2[] = $hasil_barang_keluar['idbarang'];
		$sql2 = 'UPDATE barang SET stok=? WHERE id = ?';
		$row2 = $config -> prepare($sql2);
		$row2 -> execute($data2);

		$sql3 = 'DELETE FROM barangkeluar WHERE id=?';
		$row3 = $config -> prepare($sql3);
		$row3 -> execute($data);
		echo '<script>window.location="../../index.php?page=barang-keluar&&remove=hapus-data"</script>';
	}
}

