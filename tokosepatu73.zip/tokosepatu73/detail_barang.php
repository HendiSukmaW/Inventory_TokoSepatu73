<?php 
require 'config.php';
//kenciSimpleCrypt(json_encode(['id' => $hasil['id'], 'nama' => $hasil['nama_kategori'], 'merk' => $hasil['merk'], 'warna' => $hasil['warna'], 'ukuran' => $hasil['ukuran'], 'key' => 'hendi-ta-key']));

if(isset($_GET['id']) && $_GET['id'] != ""){
    
    print_r($dataqrd);
}else{
    
}

?>