<?php


date_default_timezone_set("Asia/Jakarta");
error_reporting(1);

// sesuaikan dengan server anda
$host 	= 'localhost'; // host server
$user 	= 'root';  // username server
$pass 	= ''; // password server, kalau pakai xampp kosongin saja
$dbname = 'db_toko'; // nama database anda

$domain = "http://localhost/tokosepatu73/";
$detail_url = $domain . "detail_barang.php?id=";

try{
	$config = new PDO("mysql:host=$host;dbname=$dbname;", $user,$pass);
	//echo 'sukses';
}catch(PDOException $e){
	echo 'KONEKSI GAGAL' .$e -> getMessage();
}

$view = 'fungsi/view/view.php'; // direktori fungsi select data

function kenciSimpleCrypt($string, $action = 'e' ) {
    $secret_key = 'hendi';
    $secret_iv = 'tugas-akhir';
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $key = hash( 'sha256', $secret_key );
    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
    if ( $action == 'e' ) {
        $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
    } else if( $action == 'd' ){
        $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
    }
    return $output;
}
?>

